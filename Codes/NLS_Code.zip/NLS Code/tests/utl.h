#ifndef _UTL_H_
#define _UTL_H_

int read_string ( FILE *in, char string[80] );

#endif
