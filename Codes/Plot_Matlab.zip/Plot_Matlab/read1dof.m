clc;
clear all;
close all;

%user input
outFileName_u = 'function_0.out';
dir =  '../bin/vc7/';

% open out files...
outFileName_u = [dir,outFileName_u];
fid_u = fopen(outFileName_u);

% Initialization
cnt = 1;

% Read data...
tline_u = fgetl(fid_u);
data_u = sscanf(tline_u, '%lf %lf', [1,2]);
while ( ~feof(fid_u) && ( isempty(data_u) == 0 ))
        u(cnt) = data_u(1);
        totLoadFactor_u(cnt) = data_u(2);
        cnt = cnt + 1;
        
        tline_u = fgetl(fid_u);
        data_u = sscanf(tline_u, '%lf %lf', [1,2]);
end
fclose(fid_u);

% Plotting output...
figure('Position',[100 100 700 550]);
plot(u, totLoadFactor_u, '-ok', 'MarkerFaceColor','k', 'markersize', 2);
xText = xlabel('Displacement', 'FontSize', 12); 
yText = ylabel ('Load Factor', 'FontSize', 12); 
set(gca, 'FontSize', 12);
grid on
