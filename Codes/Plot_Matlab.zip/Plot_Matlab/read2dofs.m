clc;
close all;
clear all;

%user input
outFileName_u = 'node0v.out';
outFileName_v = 'node1v.out';
dir = '../bin/vc7/';

% open out files...
outFileName_u = [dir,outFileName_u];
outFileName_v = [dir,outFileName_v];
fid_u = fopen(outFileName_u);
fid_v = fopen(outFileName_v);

% Initialization
cnt = 1;

% Read data...
tline_u = fgetl(fid_u);
tline_v = fgetl(fid_v);
data_u = sscanf(tline_u, '%lf %lf', [1,2]);
data_v = sscanf(tline_v, '%lf %lf', [1,2]);
while ( ~feof(fid_u) ) && ( ~feof(fid_v) ) && ( isempty(data_u) == 0 )&& ( isempty(data_v) == 0 )
    u(cnt) = data_u(1);
    v(cnt) = data_v(1);

    totLoadFactor_u(cnt) = data_u(2);
    totLoadFactor_v(cnt) = data_v(2);

    cnt = cnt + 1;

    tline_u = fgetl(fid_u);
    tline_v = fgetl(fid_v);

    data_u = sscanf(tline_u, '%lf %lf', [1,2]);
    data_v = sscanf(tline_v, '%lf %lf', [1,2]);
end
fclose(fid_u);
fclose(fid_v);


% Plotting output...
figure('Position',[100 100 700 550]);
plot(u, totLoadFactor_u, '-ok', 'MarkerFaceColor','k', 'MarkerSize', 2);
hold on
plot(v, totLoadFactor_v, '-ok', 'Color', [0.6 0.6 0.6], ...
    'MarkerFaceColor', [0.6 0.6 0.6], 'MarkerSize', 2);
xText = xlabel('Displacement', 'FontSize', 12); 
yText = ylabel ('Load Factor', 'FontSize', 12); 
set(gca, 'FontSize', 12);
grid on






