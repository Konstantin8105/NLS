clc;
clear;
close all;

%user input
outFileName_v1 = 'node1u.out';
outFileName_w1 = 'node1w.out';
outFileName_w2 = 'node2w.out';
dir = '../bin/vc7/';

% open out files...
outFileName_v1 = [dir,outFileName_v1];
outFileName_w1 = [dir,outFileName_w1];
outFileName_w2 = [dir,outFileName_w2];
fid_v1 = fopen(outFileName_v1);
fid_w1 = fopen(outFileName_w1);
fid_w2 = fopen(outFileName_w2);

% Initialization
cnt = 1;

% Read data...
tline_v1 = fgetl(fid_v1);
tline_w1 = fgetl(fid_w1);
tline_w2 = fgetl(fid_w2);

data_v1 = sscanf(tline_v1, '%lf %lf', [1,2]);
data_w1 = sscanf(tline_w1, '%lf %lf', [1,2]);
data_w2 = sscanf(tline_w2, '%lf %lf', [1,2]);

while ( ~feof(fid_v1) ) && ( ~feof(fid_w1) ) && ( ~feof(fid_w2) )...
        && ( isempty(data_v1) == 0 ) && ( isempty(data_w1) == 0 ) ...
        && ( isempty(data_w2) == 0 )
    
        v1(cnt) = data_v1(1);
        w1(cnt) = -data_w1(1); %neg
        w2(cnt) = -data_w2(1); %neg

        totLoadFactor_v1(cnt) = data_v1(2); %neg
        totLoadFactor_w1(cnt) = data_w1(2);
        totLoadFactor_w2(cnt) = data_w2(2);
        cnt = cnt + 1;
        
        tline_v1 = fgetl(fid_v1);
        tline_w1 = fgetl(fid_w1);
        tline_w2 = fgetl(fid_w2);

        data_v1 = sscanf(tline_v1, '%lf %lf', [1,2]);
        data_w1 = sscanf(tline_w1, '%lf %lf', [1,2]);
        data_w2 = sscanf(tline_w2, '%lf %lf', [1,2]);
end
fclose(fid_v1);
fclose(fid_w1);
fclose(fid_w2);

% Plotting output...
figure('Position',[100 100 900 1000]);

subplot(2,2,1)
plot(v1, totLoadFactor_v1, '-ob', 'MarkerFaceColor','b', 'MarkerSize', 2);
xlabel('Displacement u1', 'FontSize', 20); 
ylabel ('Load', 'FontSize', 12); 
ylabel ('Load', 'FontSize', 12); 
set(gca, 'FontSize', 12);
grid on

subplot(2,2,2)
plot(w1, totLoadFactor_w1, '-or', 'MarkerFaceColor','r', 'MarkerSize', 2);
xlabel('Displacement u2', 'FontSize', 20); 
ylabel ('Load', 'FontSize', 12); 
ylabel ('Load', 'FontSize', 12); 
set(gca, 'FontSize', 12);
grid on

subplot(2,2,3)
plot(w2, totLoadFactor_w2, '-ok', 'MarkerFaceColor','k', 'MarkerSize', 2);
xlabel('Displacement u3', 'FontSize', 12); 
ylabel ('Load', 'FontSize', 12); 
set(gca, 'FontSize', 12);
grid on