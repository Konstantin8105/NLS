#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "linsys.h"

/*
 * Compressed-Sparse Row format (CSR)
 *
 *  A = [2 1 0 0]
 *      |1 2 1 0|
 *      |0 1 2 1|
 *      [0 0 1 1]
 *  
 *  Size of the matrix
 *   nrow = ncol = 4
 *  
 *  Number of nonzeros in the matrix
 *   nnz = 10
 *  
 *  Start index of each row
 *   row_ptr = { 0 | 2 | 5 | 8 | 10 }
 *  
 *  Column index
 *   col_ind = { 0 1 | 1 0 2 | 2 1 3 | 3 2 }
 *  
 *  Nonzero matrix value
 *   val     = { 2 1 | 2 1 1 | 2 1 1 | 1 1 }
 * 
 */

static void print_csr(int nrow, int *row_ptr, int *col_ind, double *val)
{
  int i,j;
  for (i=0;i<nrow;i++) {
    printf("csr line(%d) ={ ",i);
    for (j=row_ptr[i];j<row_ptr[i+1];j++) printf("(%d,%lf) ",col_ind[j], val[j]);
    printf("}\n");
  }
}

static void print_profile(int nrow,  double **a, int *c)
{
  int i,j;
  for (i=0;i<nrow;i++) {
    printf("profile line(%d) ={ ",i);
    for (j=c[i];j<=i;j++) printf("(%d,%lf)",j,a[i][j]);
    printf("}\n");
  }
}


int main(int argc, char *argv[])
{
  int i,j,k,iter;
  int row_ptr[5] = {0, 4, 8, 12, 16};
  int col_ind[16] = {0, 1, 2, 3,
                     0, 1, 2, 3,
                     0, 1, 2, 3,
                     0, 1, 2, 3};
  double val[16]  = {2, 1, 0, 0,
                     1, 2, 1, 0,
                     0, 1, 2, 1,
                     0, 0, 1, 1};
  double b[4]  = {1, 2, 3, 4};
  int nrow = 4;
  int ncol = nrow;
  int nnz = row_ptr[nrow];
  double **a = (double**) calloc(nrow,sizeof(double*));
  int *c = (int*) calloc(nrow, sizeof(int));
  double *x = (double*) calloc(nrow, sizeof(double));
  double *v;

  printf("matrix A\n");
  print_csr(nrow, row_ptr, col_ind, val);
  memset(x, 0, sizeof(double)*nrow);
  PCG_CSR(row_ptr,col_ind,val,nrow, b,x,&iter,500,1e-10);
  printf("TLS_PCG_CSR iter = %d\n", iter);
  for (i=0;i<nrow;i++) printf("x(%d) = %lf\n",i,x[i]);

  csr_eliminate_zeros(nrow, row_ptr, col_ind, val);

  printf("matrix A after eliminating zeros\n");
  print_csr(nrow, row_ptr, col_ind, val);
  memset(x, 0, sizeof(double)*nrow);
  PCG_CSR(row_ptr,col_ind,val,nrow, b,x,&iter,500,1e-10);
  printf("TLS_PCG_CSR iter = %d\n", iter);
  for (i=0;i<nrow;i++) printf("x(%d) = %lf\n",i,x[i]);

  csr_diagonal_optimized(nrow, row_ptr, col_ind, val);

  printf("matrix A after optimizing diagonal\n");
  print_csr(nrow, row_ptr, col_ind, val);
  memset(x, 0, sizeof(double)*nrow);
  PCG_CSR(row_ptr,col_ind,val,nrow, b,x,&iter,500,1e-10);
  printf("TLS_PCG_CSR iter = %d\n", iter);
  for (i=0;i<nrow;i++) printf("x(%d) = %lf\n",i,x[i]);

  csr_to_profile_pass1(nrow, row_ptr, col_ind, c);
  printf("profile from csr pass 1\n");
  for (i=0;i<nrow;i++) printf("c(%d) = %d\n",i,c[i]);
  for (i=0;i<nrow;i++) {
     v = (double *) calloc ( i-c[i]+1, sizeof(double) );
     a[i] = v - c[i];
  }
  printf("profile from csr pass 2\n");
  csr_to_profile_pass2(nrow, row_ptr, col_ind, val, a, c);
  print_profile(nrow, a, c);

  memset(x, 0, sizeof(double)*nrow);
  PCG_Profile(a, c, nrow, b, x, &iter, 500, 1e-10);
  printf("TLS_PCG_Profile iter = %d\n", iter);
  for (i=0;i<nrow;i++) printf("x(%d) = %lf\n",i,x[i]);
  free(x);
  return 1;
}
